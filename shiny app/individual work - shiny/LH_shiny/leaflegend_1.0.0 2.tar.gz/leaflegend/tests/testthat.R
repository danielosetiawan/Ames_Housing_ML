library(testthat)
library(leaflegend)

test_check("leaflegend")
